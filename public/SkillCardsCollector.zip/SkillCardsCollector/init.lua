local _, ns = ...
ns.name = "SkillCardsCollector"

local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:SetScript("OnEvent", function(_, _, a1)
  -- print("SkillCardsCollector loaded")
end)

local frame = CreateFrame("Button","SkillCardsExplorerButton",SkillCardsFrame, "UIPanelButtonTemplate")
frame:SetHeight(20)
frame:SetWidth(90)
frame:SetText("Export Collection")
frame:ClearAllPoints()
frame:SetPoint("TOP", -50, -30)
frame:RegisterForClicks("AnyUp")
frame:SetScript("OnClick", function()
  local skillCount = SkillCardUtil.GetNumSkillCards(Enum.SkillCardType.SkillNormal)
  local talentCount = SkillCardUtil.GetNumSkillCards(Enum.SkillCardType.TalentNormal)
  local skillCountG = SkillCardUtil.GetNumSkillCards(Enum.SkillCardType.SkillGolden)
  local talentCountG = SkillCardUtil.GetNumSkillCards(Enum.SkillCardType.TalentGolden)

  SkillCardsExplorerCollectedCardsDB = {}

  local collectedSkillNormal = {}
  local collectedSkillGolden = {}
  local collectedTalentNormal = {}
  local collectedTalentGolden = {}

  function dumpCard(index, typ, collection)
    local card = SkillCardUtil.GetSkillCardAtIndex(typ, index)
    table.insert(collection, { cardId = card["CardID"], rank = card["CollectedRank"] })
  end

  for index = 1, skillCount do
    dumpCard(index, Enum.SkillCardType.SkillNormal, collectedSkillNormal)
  end

  for index = 1, talentCount do
    dumpCard(index, Enum.SkillCardType.TalentNormal, collectedTalentNormal)
  end

  for index = 1, skillCountG do
    dumpCard(index, Enum.SkillCardType.SkillGolden, collectedSkillGolden)
  end

  for index = 1, talentCountG do
    dumpCard(index, Enum.SkillCardType.TalentGolden, collectedTalentGolden)
  end

  SkillCardsExplorerCollectedCardsDB = {
    abilityNormal = collectedSkillNormal,
    abilityGolden = collectedSkillGolden,
    talentNormal = collectedTalentNormal,
    talentGolden = collectedTalentGolden
  }

  Internal_CopyToClipboard(ns.json.encode(SkillCardsExplorerCollectedCardsDB))
  print("Card collection stored in your clipboard. Paste it in the build planner at https://drthum.github.io/ascension-build-planner/")
end )

local spellsummaryExportButton = CreateFrame("Button", "SpellTalentSummaryExport", nil, "UIPanelButtonTemplate")
spellsummaryExportButton:RegisterEvent("ADDON_LOADED")
spellsummaryExportButton:SetHeight(20)
spellsummaryExportButton:SetWidth(90)
spellsummaryExportButton:SetText("Export Summary")
spellsummaryExportButton:RegisterForClicks("AnyUp")
spellsummaryExportButton:Hide()
spellsummaryExportButton:SetScript("OnClick", function()
  local skillSummary = {}
  for i, entry in ipairs(C_CharacterAdvancement.GetKnownSpellEntries()) do
    local spells = entry["Spells"]
    table.insert(skillSummary, spells[#spells])
  end

  local talentSummary = {}
  for i, entry in ipairs(C_CharacterAdvancement.GetKnownTalentEntries()) do
    local spells = entry["Spells"]
    table.insert(talentSummary, spells[#spells])
  end

  local cardedAbility = {
    normal = {},
    golden = {}
  }
  for index=1,2 do
    local cardNormal = SkillCardUtil.GetCardInfoAtIndex(Enum.SkillCardType.SkillNormal, index)
    if cardNormal ~= nil then
      table.insert(cardedAbility.normal, cardNormal['CardID'])
    end

    local cardGolden = SkillCardUtil.GetCardInfoAtIndex(Enum.SkillCardType.SkillGolden, index)
    if cardGolden ~= nil then
      table.insert(cardedAbility.golden, cardGolden['CardID'])
    end
  end

  local cardedTalent = {
    normal = {},
    golden = {}
  }
  for index=1,3 do
    local cardNormal = SkillCardUtil.GetCardInfoAtIndex(Enum.SkillCardType.TalentNormal, index)
    if cardNormal ~= nil then
      table.insert(cardedTalent.normal, cardNormal['CardID'])
    end

    local cardGolden = SkillCardUtil.GetCardInfoAtIndex(Enum.SkillCardType.TalentGolden, index)
    if cardGolden ~= nil then
      table.insert(cardedTalent.golden, cardGolden['CardID'])
    end
  end

  local summary = {
    skills = skillSummary,
    talents = talentSummary,
    carded = {
      ability = cardedAbility,
      talent = cardedTalent
    }
  }

  Internal_CopyToClipboard(ns.json.encode(summary))
  print("Current build stored in your clipboard. Paste it in the build planner at https://drthum.github.io/ascension-build-planner/")
end )
spellsummaryExportButton:SetScript("OnEvent", function(self, event, addonname)
  if addonname == "Ascension_CharacterAdvancement" then
      local charAdvFrame = _G["CharacterAdvancement"]
      spellsummaryExportButton:SetParent(charAdvFrame)
      spellsummaryExportButton:ClearAllPoints()
      spellsummaryExportButton:SetPoint("TOP", charAdvFrame, "TOP", -40, -100)
      spellsummaryExportButton:Show()
  end
end)

function dump(o)
  if type(o) == 'table' then
     local s = '{ '
     for k,v in pairs(o) do
        if type(k) ~= 'number' then k = '"'..k..'"' end
        s = s .. '['..k..'] = ' .. dump(v) .. ','
     end
     return s .. '} '
  else
     return tostring(o)
  end
end
