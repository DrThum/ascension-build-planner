local _, ns = ...
ns.name = "SkillCardsCollector"

local f = CreateFrame("Frame")
f:RegisterEvent("ADDON_LOADED")
f:SetScript("OnEvent", function(_, _, a1)
  -- print("SkillCardsCollector loaded")
end)

local frame = CreateFrame("Button","SkillCardsExplorerButton",
SkillCardsFrame, "UIPanelButtonTemplate")
frame:SetHeight(20)
frame:SetWidth(80)
frame:SetText("Export Collection")
frame:ClearAllPoints()
frame:SetPoint("TOP", -50, -30)
frame:RegisterForClicks("AnyUp")
frame:SetScript("OnClick", function()
  local skillCount = SkillCardUtil.GetNumSkillCards(Enum.SkillCardType.SkillNormal)
  local talentCount = SkillCardUtil.GetNumSkillCards(Enum.SkillCardType.TalentNormal)
  local skillCountG = SkillCardUtil.GetNumSkillCards(Enum.SkillCardType.SkillGolden)
  local talentCountG = SkillCardUtil.GetNumSkillCards(Enum.SkillCardType.TalentGolden)

  SkillCardsExplorerCollectedCardsDB = {}

  local collectedSkillNormal = {}
  local collectedSkillGolden = {}
  local collectedTalentNormal = {}
  local collectedTalentGolden = {}

  function dumpCard(index, typ, collection)
    local card = SkillCardUtil.GetSkillCardAtIndex(typ, index)
    table.insert(collection, { cardId = card["CardID"], rank = card["CollectedRank"] })
  end

  for index = 1, skillCount do
    dumpCard(index, Enum.SkillCardType.SkillNormal, collectedSkillNormal)
  end

  for index = 1, talentCount do
    dumpCard(index, Enum.SkillCardType.TalentNormal, collectedTalentNormal)
  end

  for index = 1, skillCountG do
    dumpCard(index, Enum.SkillCardType.SkillGolden, collectedSkillGolden)
  end

  for index = 1, talentCountG do
    dumpCard(index, Enum.SkillCardType.TalentGolden, collectedTalentGolden)
  end

  SkillCardsExplorerCollectedCardsDB = {
    abilityNormal = collectedSkillNormal,
    abilityGolden = collectedSkillGolden,
    talentNormal = collectedTalentNormal,
    talentGolden = collectedTalentGolden
  }

  Internal_CopyToClipboard(ns.json.encode(SkillCardsExplorerCollectedCardsDB))
  print("Card collection stored in your clipboard. Paste it in the build planner at https://drthum.github.io/ascension-build-planner/")
end )
